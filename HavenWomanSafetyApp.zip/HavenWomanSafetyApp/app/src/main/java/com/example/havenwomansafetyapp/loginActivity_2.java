package com.example.havenwomansafetyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class loginActivity_2 extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private TextView textViewError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewError = findViewById(R.id.textViewError);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get entered username and password
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                // Validate the username and password (example: simple validation)
                if (isValidCredentials(username, password)) {
                    // Successful login, you can navigate to the next activity or perform other actions
                    textViewError.setText(""); // Clear any previous error messages
                    Intent intent = new Intent(loginActivity_2.this, HomePage.class);
                    startActivity(intent);
                    finish();
                } else {
                    // Display error message for invalid credentials
                    textViewError.setText("Invalid username or password");
                }
            }
        });
    }

    // Example: Simple validation method, you should implement proper authentication logic
    private boolean isValidCredentials(String username, String password) {
        // Add your authentication logic here (e.g., check against a database)
        // For this example, we assume a simple condition for demonstration purposes
        return username.equals("user") && password.equals("password");
    }
}
