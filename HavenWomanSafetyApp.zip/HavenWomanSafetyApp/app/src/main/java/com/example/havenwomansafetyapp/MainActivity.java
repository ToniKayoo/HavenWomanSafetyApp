package com.example.havenwomansafetyapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    private ConstraintLayout splashScreenLayout;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize splash screen layout
        splashScreenLayout = findViewById(R.id.splashScreenLayout);

        // Simulate a delay for the splash screen (e.g., 2000 milliseconds)
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Hide the splash screen and show the main content
                hideSplashScreen();
            }
        }, 2000);
    }

    // Method to hide the splash screen and show the main content
    private void hideSplashScreen() {
        splashScreenLayout.setVisibility(View.GONE);
        // Your main content visibility should be set to visible here
    }
}
