package com.example.havenwomansafetyapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomePage extends AppCompatActivity {

    // Declare the UI elements
    private EditText editContactName;
    private EditText editContactNumber;
    private Button btnAddContact;
    private TextView tvAddedContacts;
    private TextView tvDynamicContacts;
    private Button btnEmergencyContactsPage; // New button for navigating to Emergency Contacts page

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        // Initialize UI elements
        editContactName = findViewById(R.id.editContactName);
        editContactNumber = findViewById(R.id.editContactNumber);
        btnAddContact = findViewById(R.id.btnAddContact);
        tvAddedContacts = findViewById(R.id.tvAddedContacts);
        tvDynamicContacts = findViewById(R.id.tvDynamicContacts);
        btnEmergencyContactsPage = findViewById(R.id.btnEmergencyContactsPage);

        // Set onClickListener for the "Add Contact" button
        btnAddContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered contact information
                String contactName = editContactName.getText().toString();
                String contactNumber = editContactNumber.getText().toString();

                // Validate if both name and number are not empty
                if (!contactName.isEmpty() && !contactNumber.isEmpty()) {
                    // Append the contact information to the dynamic TextView
                    String currentContacts = tvDynamicContacts.getText().toString();
                    String newContactInfo = currentContacts + "\n" + contactName + ": " + contactNumber;
                    tvDynamicContacts.setText(newContactInfo);

                    // Clear the EditTexts for the next input
                    editContactName.getText().clear();
                    editContactNumber.getText().clear();
                } else {
                    // Provide feedback to the user about invalid input
                    Toast.makeText(HomePage.this, "Please enter both name and number", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set onClickListener for the "Emergency Contacts" button
        btnEmergencyContactsPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the Emergency Contacts page
                Intent intent = new Intent(HomePage.this, emergency_contact.class);
                startActivity(intent);
            }
        });
    }
}
